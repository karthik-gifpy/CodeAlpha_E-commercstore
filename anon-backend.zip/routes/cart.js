const express = require('express');
const router = express.Router();
const CartItem = require('../models/CartItem');

router.get('/', async (req, res) => {
  const items = await CartItem.find();
  res.json(items);
});

router.post('/add', async (req, res) => {
  const item = new CartItem(req.body);
  await item.save();
  res.status(201).json(item);
});

router.post('/clear', async (req, res) => {
  await CartItem.deleteMany();
  res.json({ message: 'Cart cleared' });
});

module.exports = router;